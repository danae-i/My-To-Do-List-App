from flask import Flask, redirect, render_template, request
from datetime import datetime, date, timedelta

app = Flask(__name__)

def load():
    try:
        with open('tasks.txt', "r", encoding='utf-8') as taskfile:
            tasks = taskfile.readlines()
            tasks = [task.strip() for task in tasks]
    except FileNotFoundError:
        tasks = []
    return tasks

@app.route("/")
def home():
    today_tasks=today()
    week_tasks=week()
    return render_template("home.html", tasks=today_tasks, week_tasks=week_tasks)

@app.route("/add", methods=["POST"])
def add_task():
    name = request.form.get("task-name")
    date = request.form.get("task-date")
    time = request.form.get("task-time")

    if name and date:
        year, month, day = date.split("-")
        fdate=f" {day}/{month}/{year}"
        if time:
            with open("tasks.txt", 'a', encoding='utf-8') as taskfile:
                taskfile.write(f"{name} {fdate} {time}\n")
        else:
            with open("tasks.txt", 'a', encoding='utf-8') as taskfile:
                taskfile.write(f"{name} {fdate} (--:--)\n")
    return redirect("/my-list")

@app.route("/my-list")
def my_list():
    tasks=load()
    return render_template("my_list.html", tasks=tasks)

@app.route("/settings")
def settings():
    return render_template("settings.html")

@app.route("/delete", methods=["POST"])
def delete():
    task_d = request.form.get("task")
    tasks = load()
    tasks = [task for task in tasks if task != task_d]
    with open("tasks.txt", "w", encoding='utf-8') as file:
        for task in tasks:
            file.write(task + "\n")
    return redirect("/my-list")

def today():
    today = date.today()
    ftoday = today.strftime("%d/%m/%Y")
    tasks = load()

    today_tasks = []
    for task in tasks:
        parts = task.rsplit(' ', 2)

        if len(parts) >= 3:
            task_date = parts[1]
            if task_date == ftoday:
                today_tasks.append(parts[0])
    return today_tasks

def week():
    today = date.today()
    start_of_week = today - timedelta(days=today.weekday())
    end_of_week = start_of_week + timedelta(days=6)

    week_tasks = []
    tasks = load()

    for task in tasks:
        parts = task.rsplit(' ', 2)
        if len(parts) >= 3:
            task_date_str = parts[1]
            try:
                task_date = datetime.strptime(task_date_str, "%d/%m/%Y").date()
                if start_of_week <= task_date <= end_of_week:
                    week_tasks.append(parts[0])
            except ValueError:
                continue

    return week_tasks


if __name__ == '__main__':
    app.run(debug=True) 
